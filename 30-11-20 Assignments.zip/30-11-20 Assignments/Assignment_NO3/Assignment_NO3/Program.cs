﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;



namespace Assignment_NO3
{
    class Bank
    {
        int NetBalance1;
        int TranAmount;
        public Bank(int NetBalance1, int TranAmount)
        {
            this.NetBalance1 = NetBalance1;
            this.TranAmount = TranAmount;
        }
        static void Main(string[] args)
        {
            Bank b = new Bank(1000, 100);
            // b.NetBalance = 1000;
            // b.Deposit(100);
            // b.Withdrawal(50);
            Thread t1 = new Thread(b.Deposit);
            Thread t2 = new Thread(b.Withdrawal);
            t1.Start();
            t2.Start();
        }
        public int NetBalance
        {
            get { return NetBalance1; }
            set { NetBalance1 = value; }
        }

        void Deposit()
        {
            NetBalance = NetBalance + TranAmount;
            Console.WriteLine("deposit..." + NetBalance);
        }



        void Withdrawal()
        {

            NetBalance = NetBalance - TranAmount;
            Console.WriteLine("withdraw..." + NetBalance);
        }



    }




}

